package com.example.gesturecontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/** ينفّذ الأوامر على الهاتف: رجوع، رئيسية، تمرير، نقر... */
class ControlAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ControlAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    fun perform(cmd: Command) {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()

        when (cmd) {
            Command.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
            Command.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            Command.RECENTS -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            Command.CLICK -> tap(w / 2f, h / 2f)
            Command.SWIPE_UP -> swipe(w / 2f, h * 0.7f, w / 2f, h * 0.3f)
            Command.SWIPE_DOWN -> swipe(w / 2f, h * 0.3f, w / 2f, h * 0.7f)
            Command.SWIPE_LEFT -> swipe(w * 0.8f, h / 2f, w * 0.2f, h / 2f)
            Command.SWIPE_RIGHT -> swipe(w * 0.2f, h / 2f, w * 0.8f, h / 2f)
        }
        GestureState.lastAction.value = cmd.label
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        dispatch(GestureDescription.StrokeDescription(path, 0, 50))
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        dispatch(GestureDescription.StrokeDescription(path, 0, 300))
    }

    private fun dispatch(stroke: GestureDescription.StrokeDescription) {
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
}
