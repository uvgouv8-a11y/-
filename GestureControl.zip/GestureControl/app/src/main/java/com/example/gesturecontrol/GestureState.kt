package com.example.gesturecontrol

import kotlinx.coroutines.flow.MutableStateFlow

/** حالة مشتركة بين الخدمة والواجهة. */
object GestureState {
    val running = MutableStateFlow(false)
    val status = MutableStateFlow("متوقف")
    val gesture = MutableStateFlow("—")
    val lastAction = MutableStateFlow("—")
}
