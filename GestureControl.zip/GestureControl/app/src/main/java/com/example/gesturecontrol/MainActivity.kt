package com.example.gesturecontrol

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var gestureText: TextView
    private lateinit var actionText: TextView
    private lateinit var toggleButton: Button

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result[Manifest.permission.CAMERA] == true) {
                startGestureService()
            } else {
                GestureState.status.value = "إذن الكاميرا مطلوب"
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        gestureText = findViewById(R.id.gestureText)
        actionText = findViewById(R.id.actionText)
        toggleButton = findViewById(R.id.toggleButton)

        findViewById<Button>(R.id.accessibilityButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        toggleButton.setOnClickListener {
            if (GestureState.running.value) {
                stopService(Intent(this, GestureService::class.java))
            } else {
                requestPermissionsAndStart()
            }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { GestureState.status.collect { statusText.text = "الحالة: $it" } }
                launch { GestureState.gesture.collect { gestureText.text = "الإيماءة: $it" } }
                launch { GestureState.lastAction.collect { actionText.text = "آخر أمر: $it" } }
                launch {
                    GestureState.running.collect {
                        toggleButton.text =
                            if (it) "إيقاف التحكم بالإيماءات" else "2) تشغيل التحكم بالإيماءات"
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (ControlAccessibilityService.instance == null && !GestureState.running.value) {
            GestureState.status.value = "فعّل خدمة إمكانية الوصول (الخطوة 1) ثم شغّل التحكم"
        }
    }

    private fun requestPermissionsAndStart() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) needed += Manifest.permission.CAMERA
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) needed += Manifest.permission.POST_NOTIFICATIONS

        if (needed.isEmpty()) startGestureService()
        else permissionLauncher.launch(needed.toTypedArray())
    }

    private fun startGestureService() {
        ContextCompat.startForegroundService(this, Intent(this, GestureService::class.java))
    }
}
